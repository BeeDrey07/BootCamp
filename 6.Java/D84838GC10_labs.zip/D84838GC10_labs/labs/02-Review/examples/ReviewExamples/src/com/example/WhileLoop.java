package com.example;

public class WhileLoop {
    
    public static void main(String args[]){
        
        int i = 0;
        int[] numbers = {100, 200, 300};
        
        while (i < numbers.length ){
            System.out.println("Number: " + numbers[i]);
            i++;
        }
        
    }
    
}
