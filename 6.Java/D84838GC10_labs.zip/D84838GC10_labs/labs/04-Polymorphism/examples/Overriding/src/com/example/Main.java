package com.example;

public class Main {
  public static void main(String[] args) {
    EmployeeTest.main(args);
    ManagerTest.main(args);
    VirtualInvokeTest01.main(args);
    VirtualInvokeTest02.main(args);
  }
}
