package example.com;

import static java.lang.Math.*;

public class A05StaticImportTest {
    public static void main(String[] args) {
      System.out.println("Random: " + random()*10);
    }
}