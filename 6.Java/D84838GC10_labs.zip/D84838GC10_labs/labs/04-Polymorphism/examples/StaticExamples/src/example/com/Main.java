package example.com;

public class Main {
  public static void main(String[] args) {
    A01MathTest.main(args);
    A02StaticMethodTest.main(args);
    A03CounterTest.main(args);
    A04StaticInitializerTest.main(args);
    A05StaticImportTest.main(args);
  }
}
