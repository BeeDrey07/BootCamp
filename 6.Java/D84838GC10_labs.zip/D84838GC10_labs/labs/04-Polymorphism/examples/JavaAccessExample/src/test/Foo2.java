package test;

public class Foo2 {
    protected int result = 20;
}
